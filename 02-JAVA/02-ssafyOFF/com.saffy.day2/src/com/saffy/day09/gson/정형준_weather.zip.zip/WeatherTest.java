package com.saffy.day09.gson;

public class WeatherTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			new WeatherService();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
